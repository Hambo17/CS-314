#include <stdio.h>
#include <stdlib.h>

/*
loop(long, long):			a = %rdi, b = %rsi
        movq    %rsi, %rcx		%rcx = b
        movl    $2, %eax    		%rax = 2, mask
        movl    $0, %edx    		%rdx = 0, result
        jmp     .L2			Unconditional jump to L2
.L3:
        movq    %rax, %r8		%r8 = mask
        andq    %rdi, %r8		%r8 & rdi, bitwise and mask and a
        orq     %r8, %rdx		0 | %r8, bitwise or mask and result
        salq    %cl, %rax   		shift mask left by b
.L2:
        cmpq    $1, %rax		(mask - 1), sets sign flag  (first case, 2-1)
        jg      .L3			Jmp if greater, signed. If rax is greater than 0.
        movq    %rdx, %rax		%rax = %rdx
        ret				return
*/
        
long loop(long a, long b) {
	long result = 0;
	for (long mask = 2; mask > 1; mask <<= b) {
		result |= (mask & a);
	}
  	return result;
}
	
int main(int argc, char *argv[]) {
  if (argc == 3) {
    long a = strtol(argv[1], NULL, 10);
    long b = strtol(argv[2], NULL, 10);
    printf("loop(%ld, %ld): %ld\n", a, b, loop(a, b));
  } else {
    printf("loop(%ld, %ld): %ld\n", 1, 1, loop(1, 1));
    printf("loop(%ld, %ld): %ld\n", 3, 2, loop(3, 2));
    printf("loop(%ld, %ld): %ld\n", 5, 1, loop(5, 1));
    printf("loop(%ld, %ld): %ld\n", 7, 2, loop(7, 2));
    printf("loop(%ld, %ld): %ld\n", 9, 1, loop(9, 1));
  }
  return 0;
}
	
	
