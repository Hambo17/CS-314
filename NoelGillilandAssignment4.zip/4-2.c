#include <stdio.h>
#include <stdlib.h>

long iterativeFact(long x){
	long result = 1;
	for (int i = 1; i <= x; i++){
		result *= i;
	}
	return result;

}

long recursiveFact(long x){
	if (x == 0){
	return 1;
	}
	else{
	return(x * recursiveFact(x-1));
	}
	
}


/*

iterativeFact(long):
        movl    $1, %eax		rax = 1
        movl    $1, %ecx		rcx = 1
        jmp     .L2			jump to L2
.L3:
        imulq   %rdx, %rcx		rcx = rcx * rdx
        addl    $1, %eax		rax = rax + 1
.L2:					
        movslq  %eax, %rdx		rdx = rax, sign extended 64bit
        cmpq    %rdi, %rdx		rdx - rdi, set sign flags based on result
        jle     .L3			jump to L3 if cmpq resulted in negative or zero int (if rdx <= rax)
        movq    %rcx, %rax		rax = rcx
        ret				pop return address
        
        
recursiveFact(long):
        testq   %rdi, %rdi		checks if rdi is zero
        jne     .L11			if rdi is not zero, jump to L11
        movl    $1, %eax		rax = 1
        ret				pop return address
.L11:
        pushq   %rbx			push rbx onto stack
        movq    %rdi, %rbx		rbx = rdi
        leaq    -1(%rdi), %rdi		rdi = rdi - 1
        call    recursiveFact(long)	calls function(rdi - 1), push return address
        imulq   %rbx, %rax		rax = rax * rbx
        popq    %rbx			remove rbx from call stack
        ret				pop return address
        
*/



int main(int argc, char *argv[]) {
  if (argc == 2) {
    long x = strtol(argv[1], NULL, 10);
    printf("iterativeFact(%ld): %ld\n", x, iterativeFact(x));
    printf("recursiveFact(%ld): %ld\n", x, recursiveFact(x));
  } else {
    printf("iterativeFact(%ld): %ld\n", 0, iterativeFact(0));
    printf("recursiveFact(%ld): %ld\n", 0, recursiveFact(0));
    printf("iterativeFact(%ld): %ld\n", 1, iterativeFact(1));
    printf("recursiveFact(%ld): %ld\n", 1, recursiveFact(1));
    printf("iterativeFact(%ld): %ld\n", 5, iterativeFact(5));
    printf("recursiveFact(%ld): %ld\n", 5, recursiveFact(5));
  }
  return 0;
}
