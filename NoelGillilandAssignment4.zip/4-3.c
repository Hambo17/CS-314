#include <stdlib.h>
#include <stdio.h>


void transpose(long a[4][4]) {
  for (long i = 0; i < 4; ++i) {
    for (long j = 0; j < i; ++j) {
      long t1 = a[i][j];
      long t2 = a[j][i];
      a[i][j] = t2;
      a[j][i] = t1;
    }
  } 
}

/*
transpose:
        movq    %rdi, %r9		r9 = a
        movl    $0, %r8d		i = 0, zeros out lower 32 bits
.L2:
        testq   %r8, %r8		checks if i == 0
        jle     .L9			jumps to L9, if i <= 0
        movq    %r8, %rax		rax = i
        salq    $5, %rax		shift rax left by 5 bits, rax  = i * 32
        addq    %rdi, %rax		rax = (i * 32) + a
        leaq    (%rdi,%r8,8), %rdx	rdx = i * 8 + a
.L3:
        movq    (%rax), %rcx		t1 = a[i][j]
        movq    (%rdx), %rsi		t2 = a[j][i]
        movq    %rsi, (%rax)		a[i][j] = t2
        movq    %rcx, (%rdx)		a[j][i] = t1
        addq    $8, %rax		rax = rax +8 (move to the next element in the row)
        addq    $32, %rdx		rdx = rdx +32 (move to the next element in the column)
        cmpq    %r9, %rax		rax - a, sets sign flag based on result
        jne     .L3			if rax != a, jump to L3
        addq    $1, %r8			i = i +1
        cmpq    $4, %r8			i - 4, set sign flag
        je      .L1			jump, if i == 4
        addq    $40, %r9		a = a + 40
        jmp     .L2			jump to L2, unconditional
.L9:
        addq    $1, %r8			i = i + 1
        addq    $40, %r9		a = a + 40
        jmp     .L2			jump to L2, unconditional
.L1:
        ret				pop return address
*/


void transposeOpt(long a[4][4]) {
  for (long i = 0; i < 4; ++i) {
    long *rp = &a[i][0];
    long *cp = &a[0][i];
    for (long j = 0; j < i; ++j) {
    	long temp = *rp;
    	*rp = *cp;
    	*cp = temp;
    	
    	rp++;
    	cp += 4;
    	
      // TODO - swap data at rp, cp pointers, increment rp, cp
      // (as shown in the optimized x86-64 code above)
    }
  }
}










void print(long a[4][4]) {
  for (int i = 0; i < 4; ++i) {
    for (int j =  0; j < 4; ++j) {
      printf("%ld ", a[i][j]);
    }
    printf("\n");
  }
}



int main(int argc, char *argv[]) {
  if (argc == 17) {
    long a[4][4];
    long b[4][4];
    for (int i = 0; i < 4; ++i) {
      for (int j = 0; j < 4; ++j) {
        a[i][j] = strtol(argv[i * 4 + j + 1], NULL, 10);
        b[i][j] = a[i][j];
      }
    }
    transpose(a);
    printf("transpose(a)\n");
    print(a);
    transposeOpt(b);
    printf("trasnposeOpt(b)\n");
    print(b);
  } else {
  	long a[4][4] = {
            {1, 2, 3, 4},
            {5, 6, 7, 8},
            {9, 10, 11, 12},
            {13, 14, 15, 16}
        };
    	long b[4][4] = {
            {1, 2, 3, 4},
            {5, 6, 7, 8},
            {9, 10, 11, 12},
            {13, 14, 15, 16}
        };
        printf("Original Matrix:\n");
        print(a);

        transpose(a);
        printf("transpose(a)\n");
        print(a);

        transposeOpt(b);
        printf("transposeOpt(b)\n");
        print(b);
        
  }
  return 0;
}
