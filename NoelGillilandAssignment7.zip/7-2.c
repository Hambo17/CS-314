#include <stdio.h>
#include <stdlib.h>
#include <time.h>

struct ColorPoint {
    long a;
    long r;
    long g;
    long b;
};

void f(struct ColorPoint **points, int n, long *dest) {
    long sum = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            sum += points[i][j].a;
            sum += points[i][j].r;
            sum += points[i][j].g;
            sum += points[i][j].b;
        }
    }
    *dest = sum;
    //points[0][0].a = 0 	Tag: 0		Cold miss
    //points[0][0].r = 8	Tag: 0		hit
    //points[0][0].g = 16	Tag: 0		hit
    //points[0][0].b = 24	Tag: 0		hit
    //points[0][1].a = 32	Tag: 0		hit
    //points[0][1].r = 40	Tag: 0		hit
    //points[0][1].g = 48	Tag: 0		hit
    //points[0][1].b = 56	Tag: 0		hit
    
    //Yes, the pattern will continue because of the size of the cache
    //every time we enter a new row, we will miss but it will load the entirety of the next 
    //two sections. ex ([0][2] and [0][3])
}

void g(struct ColorPoint **points, int n, long *dest) {
    long sum = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            sum += points[j][i].a;
            sum += points[j][i].r;
            sum += points[j][i].g;
            sum += points[j][i].b;
        }
    }
    *dest = sum;
    
    //points[0][0].a = 0	tag = 0		Cold miss
    //points[0][0].a = 8	tag = 0		Hit
    //points[0][0].a = 16	tag = 0		Hit
    //points[0][0].a = 24	tag = 0		Hit
    //points[1][0].r = 128	tag = 2		Critical miss
    //points[1][0].r = 136	tag = 2		Hit
    //points[1][0].r = 144	tag = 2		Hit
    //points[1][0].r = 152	tag = 2		Hit
    
    //Yes, the pattern will continue of a miss, followed by 3 hits. After each section,
    //we move to the next row, which is not loaded in our cache as it is 128 away from our starting 
    //point. 
}


void main(){

	struct ColorPoint** colorpoint = (struct ColorPoint**)malloc(2048 * sizeof(struct ColorPoint*));
	for (int i = 0; i < 2048; i++){
		colorpoint[i] = (struct ColorPoint*)malloc(2048 * sizeof(struct ColorPoint));
	} //Allocate a 2d array, 2048x2048
	
	//Chat gpt helped create the array alocation lines of code.
	long destination1 = 0;
	long destination2 = 0;
	int calls = 100;
	clock_t start = clock();		//Start Timer
	for (int i = 0; i < calls; i++){
	f(colorpoint, 2048, &destination1);  	//Call function f 100 times
	}
	clock_t end = clock();			//End timer
	
	double totaltime = ((double) (end - start)) / CLOCKS_PER_SEC;
	printf("%f\n", totaltime);		//print difference between start and end
		
	start = clock();			//Start timer
	for (int i = 0; i < calls; i++){
	g(colorpoint, 2048, &destination2);	//Call function g 100 Times
	}
	end = clock();				//End Timer
	
	totaltime = ((double) (end - start)) / CLOCKS_PER_SEC;
	printf("%f\n", totaltime);		//Print difference between start and end

	//Function f is faster than function g by about 2/5. This is due
	//to the way that the processor reads memory, being row dominate.
	//In the function g, we have twice as many cache misses becuase 
	//we are going through the array by columns, not rows.






}












