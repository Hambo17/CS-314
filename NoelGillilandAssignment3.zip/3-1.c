#include <stdlib.h>
#include <stdio.h>

struct IntArray {
    int length;
    int *dataPtr;
};
struct IntArray* mallocIntArray(int length){
	struct IntArray *intArray = (struct IntArray *)malloc(sizeof(struct IntArray));
	(*intArray).dataPtr = (int *)malloc(length * sizeof(int));
	(*intArray).length = length;
	for (int i = 0; i < length; i++) {
        (*intArray).dataPtr[i] = 0;
    	}
	return (intArray);
}
//Chatgpt helped create this function. I was confused on syntax
void freeIntArray(struct IntArray *intarray){
	//Frees the heap memory used by the array
	free((*intarray).dataPtr);
	free(intarray);
}
void readIntArray(struct IntArray *array){
	//Reads a set of numbers from the user, determined by length given also by user
	//These numbers are positive
	int number;
	for (int i = 0; i < (*array).length; i++){
	while(1) {
		printf("Enter a postive integer: ");
	int result = scanf("%d", &number);
	if (result <= 0){
		printf("Invalid input. Enter a positive integer.\n");
		while (getchar() != '\n');
	}
	else {
		(*array).dataPtr[i] = number;
		break;
	}
	}
}}
void printIntArray(struct IntArray *array){
	//Cycles through the array and prints each piece of data
	for (int i = 0; i < (*array).length; i++){
	if (i == (*array).length - 1){
		printf("%d", (*array).dataPtr[i]);
		break;
		}
	printf("%d, ", (*array).dataPtr[i]);
}
}
void swap(int *xp, int *yp){
	//Swaps data between two pointers
	int x = *xp;
	int y = *yp;
	*xp = y;
	*yp = x;
}
void sortIntArray(struct IntArray *array){
	//Uses a selection sort algoritm to sort the array given to us by the user
	for (int i = 0; i < (*array).length; i++){
		for (int j = i; j < (*array).length; j++){
			if ((*array).dataPtr[j] < (*array).dataPtr[i]){
			swap(&array->dataPtr[i], &array->dataPtr[j]);
			}
		}
	}
	}
// https://www.geeksforgeeks.org/selection-sort-algorithm-2/
int main() {
	int length;
	struct IntArray *myArray;
	while(1){
	printf("Enter a positive number for the array length: ");
	if (scanf("%d", &length) <= 0) {
		printf("Invalid input. Please enter a positive integer.\n");
		while (getchar() != '\n');
	} else {
		break;
	} }
	myArray = mallocIntArray(length);
	readIntArray(myArray);
	sortIntArray(myArray);
	printIntArray(myArray);
	freeIntArray(myArray);
	return 0;
}
