#include <stdlib.h>
#include <stdio.h>


//f(long, long, long):
//	subq	%rdx, %rdi      # x -= z
//	imulq	%rsi, %rdx	# y * z
//	movq	%rdi, %rax      # rax = x
//	andq	%rdx, %rax	# z & rax
//	ret

// x = rdi
// y = rsi
// z = rdx

int f(unsigned long x, unsigned long y, unsigned long z) {
	x -= z;
	z *= y;
	unsigned int rax = x;
	unsigned int result = rax & z;
	return result;
}

int main(int argc, char *argv[]) {
	if (argc ==4) {
	long x = strtol(argv[1], NULL, 10);
	long y = strtol(argv[1], NULL, 10);    
	long z = strtol(argv[1], NULL, 10);
	printf("f(%ld, %ld, %ld): %ld\n", x, y, z, f(x,y,z));
      } else {
        //TODO - add any hardcoded test cases you'd like here!
        printf("f(%ld, %ld, %ld): %ld\n", 1, 2, 4, f(1,2,4));
        printf("f(%ld, %ld, %ld): %ld\n", 3, 5, 7, f(3,5,7));
        printf("f(%ld, %ld, %ld): %ld\n", 10, 20, 40, f(10,20,40));
        printf("f(%ld, %ld, %ld): %ld\n", 30, 50, 70, f(30,50,70));
        printf("f(%ld, %ld, %ld): %ld\n", 30, 50, -70L, f(30,50,-70L));
      }
      return 0;
}


	
