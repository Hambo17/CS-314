#include <stdlib.h>
#include <stdio.h>

unsigned int replace (unsigned int x, int i, unsigned char b){
	// Creates a mask of ff at the desired byte location specified by i
	unsigned int mask = 0xff << (i << 3);
	// Moves our specified char b to the desired byte.
	unsigned int b_2 = (unsigned int)b << (i << 3);
	// Reverses our mask to delete the information of x at that location and replace
	// it with the information of b.
	unsigned int result = ((x & ~mask) | b_2);
return result;
}

//Logic was from me but I recieved help from Chatgpt and Andrew (TA) to understand the code

int main(int argc, char *argv[]) {
	if (argc == 4) {
	  unsigned int x = strtoul(argv[1], NULL, 16);
	  int i = strtol(argv[2], NULL, 10);
	  unsigned char b = (unsigned char)strtoul(argv[3], NULL, 16); 
	  printf("replace(%X, %d, %X): %X", x, i, b, replace(x, i, b));
	}
	else { 
	printf("replace(%X, %X, %X): %X\n", 0x12345678, 3, 0xAB, replace(0x12345678, 3, 0xAB));
	printf("replace(%X, %X, %X): %X\n", 0x12345678, 3, 0xAB, replace(0x12345678, 2, 0xAB));
	printf("replace(%X, %X, %X): %X\n", 0x12345678, 3, 0xAB, replace(0x12345678, 1, 0xAB));
	printf("replace(%X, %X, %X): %X\n", 0x12345678, 3, 0xAB, replace(0x12345678, 0, 0xAB));
	}
	return 0;
}


