#include <stdlib.h>
#include <stdio.h>

int evenBit(unsigned int x){

	//Removes all odd bits, leaving 1's only in even indexes.
	unsigned int test = ((x) & (0x55555555));
	//Returns 1, if "test" is not zero. Returns 0, if "test" is zero.
	return !!(test);
}

//Chatgpt taught me how ! works upon zero and nonzero integers.

int main(int argc, char *argv[]) {
  if (argc == 2) {
    unsigned int x = strtoul(argv[1], NULL, 16);
    printf("evenBit(%X): %X\n", x, evenBit(x));
  } else {
    printf("evenBit(%X): %X\n", 0x1, evenBit(0x1));
    printf("evenBit(%X): %X\n", 0x2, evenBit(0x2));
    printf("evenBit(%X): %X\n", 0x3, evenBit(0x3));
    printf("evenBit(%X): %X\n", 0x4, evenBit(0x4));
    printf("evenBit(%X): %X\n", 0xFFFFFFFF, evenBit(0xFFFFFFFF));
    printf("evenBit(%X): %X\n", 0xAAAAAAAA, evenBit(0xAAAAAAAA));
    printf("evenBit(%X): %X\n", 0x55555555, evenBit(0x55555555));
    
  }
  return 0;
}
