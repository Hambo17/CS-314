#include <stdio.h>
#include <stdlib.h>


	//The function printBytes will take the pointer to a byte sequence as well as the
	//number of bytes in the type of data given, (Floats, Ints...), in order to list off 
	//said byte sequence in a series of 2 bit increments due to "%.2x".
	//For example, given an int with a byte length of 4, we would expect a result in the
	//form "xx xx xx xx", obviously each x being different. Each of these pairs of xx's
	//represent the hex representation of that byte.
void printBytes(unsigned char *start, int len) {
    for (int i = 0; i < len; ++i) {
        printf(" %.2x", start[i]);
    }
    printf("\n");
}

void printInt(int x) {
    printBytes((unsigned char *) &x, sizeof(int));
}

void printFloat(float x) {
    printBytes((unsigned char *) &x, sizeof(float));
}


int main(){
	int num2 = 305419002;
	printInt(num2);
	//This Results in the output of "fa 52 34 12"
	//305419002 in Hex form is 123452FA. 
	//Because it begins with the least significant byte, this
	//implies it it using little endian.
	
	int num1 = 85920315;
	printInt(num1);
	
	 
	int float1 = 725732.5914;
	int float2 = 8891.4001;
	printFloat(float1);
	printFloat(float2);
	//Float2 of 8891.4001 results in "00 ec 0a 46" which translates
	//in hex to 0x460aec00. However when that hex is converted back
	//it results in 8891. The formatting still uses little endian
	//as expected, however I am unsure as to why the number rounds
	//down, just as float1 rounds up when reconverted. I suspect it
	//it has to do with the fact that the decimal values are not 
	//direct powers of 2.
	
	
	
	return 0;
}








