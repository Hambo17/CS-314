#include <stdlib.h>
#include <stdio.h>

unsigned int combine(unsigned int x, unsigned int y) {
    // Creates a mask that extracts byte 3 from x
    unsigned int a = x & 0xFF000000;
    // Creates a mask that extracts bytes 2-0 from y
    unsigned int b = y & 0x00FFFFFF;
    // Returns the or of A and B, Combines byte 3 of x and bytes 2-0 of y	
    return (a | b);
}

//The logic behind the function was by me, however the code itself was written
//by myself and chatgpt.

int main(int argc, char *argv[]) {
    if (argc == 3) {
        unsigned int x = strtoul(argv[1], NULL, 16);
        unsigned int y = strtoul(argv[2], NULL, 16);

        printf("combine(%X, %X): %X\n", x, y, combine(x, y));
    } else {
        printf("combine(%X, %X): %X\n", 0x12345678, 0xABCDEF00, combine(0x12345678, 0xABCDEF00));
        printf("combine(%X, %X): %X\n", 0xABCDEF00, 0x12345678, combine(0xABCDEF00, 0x12345678));
    }
    return 0;
}

