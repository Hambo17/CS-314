#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void f(float *a, int length, float *dest) {
  float prod = 1.0f;
  for (int i = 0; i < length; ++i) {
    if (a[i] != 0.0f) {
      prod *= a[i];
    }
  }
  *dest = prod;
}

void g(float *a, int length, float *dest){
	float prod = 1.0f;
  	for (int i = 0; i < length; ++i) {
      		prod *= a[i];
 	}
  *dest = prod;
  
  //g is about 4 times faster than f.
  //this is faster because as we learned in class
  //conditional statements are really tiresome.
  //By removing this conditional, we speed up our program significantly
  
  //Calling g(c) is about twice as fast as g(b).
  //This is most likely due to the fact that are significantly
  //less items in array c, than array b. Less items to go through
  //means a faster run time. 
}


float *createArray(int length) {
  float *a = (float *)malloc(length * sizeof(float));
  for (int i = 0; i < length; ++i) {
    // 50% chance that a[i] is 0.0f, random value on the range
    // [0.75, 1.25] otherwise.
    float r = rand()/(float)RAND_MAX;
    a[i] = r < 0.5f ? 0.0f : r + 0.26f;
  }
  return a;
}


int main(){
int size = 100000;
float *arraya = createArray(size);
float destination = 1.0;
float *ptr = &destination;

int calls = 10000;
clock_t start = clock();
for (int i = 0; i < calls; i++){
f(arraya, size, ptr);
}
clock_t end = clock();
double totalTime = ((double) (end -start)) / CLOCKS_PER_SEC;
printf("%f\n", totalTime);


float *arrayb = createArray(size);
float destination2 = 1.0;
float *ptr2 = &destination2;
for (int i = 0; i < size; i++){
	arrayb[i] = (arraya[i] == 0.0f) ? 1.0f : arraya[i];
}

start = clock();
for (int i = 0; i < calls; i++){
g(arrayb, size, ptr2);
}
end = clock();
totalTime = ((double) (end - start)) / CLOCKS_PER_SEC;
printf("%f\n", totalTime);

int nonzeroCount = 0;
    for (int i = 0; i < size; i++) {
        if (arraya[i] != 0.0f) {
            nonzeroCount++;
        }
    }
    
float *arrayc = createArray(nonzeroCount);
float destination3 = 1.0;
float *ptr3 = &destination3;

int cIndex = 0;
    for (int i = 0; i < size; i++) {
        if (arraya[i] != 0.0f) {
            arrayc[cIndex++] = arraya[i];
        }
    }

start = clock();
for (int i = 0; i < calls; i++){
g(arrayc, nonzeroCount, ptr2);
}
end = clock();
totalTime = ((double) (end - start)) / CLOCKS_PER_SEC;
printf("%f\n", totalTime);

free (arraya);
free (arrayb);
free (arrayc);


return 0;


}

