#include <stdlib.h>
#include <stdio.h>
#include <time.h>

void inner(float *u, float *v, int length, float *dest) {
  float sum = 0.0f;
  for (int i = 0; i < length; ++i) {					//loop not unrolled
    sum += u[i] * v[i];							//sum the product of each item in
  }									//in the arrays
  *dest = sum;								//store answer at dest
}

void inner2(float *u, float *v, int length, float *dest) {
  float sum1 = 0.0f;
  float sum2 = 0.0f;
  float sum3 = 0.0f;
  float sum4 = 0.0f;
  int i;
  for (i = 0; i + 3 < length; i += 4) {					//loop unrolled to four times
    sum1 += u[i] * v[i];						//sum the product of each item in 
    sum2 += u[i+1] * v[i+1];						//the arrays
    sum3 += u[i+2] * v[i+2];						//sum four products each iteration
    sum4 += u[i+3] * v[i+3];						//of the loop
    
  }
  for(; i < length; i++){						//finish any odd remainder
  sum1 += u[i] * v[i];							//at most 3 iterations
  }
  *dest = sum1 + sum2 + sum3 + sum4;					//store answer at dest
}

void inner3(float *u, float *v, int length, float *dest) {
  float sum1 = 0.0f;
  float sum2 = 0.0f;
  float sum3 = 0.0f;
  float sum4 = 0.0f;
  float sum5 = 0.0f;
  float sum6 = 0.0f;
  float sum7 = 0.0f;
  float sum8 = 0.0f;
  int i;
  for (i = 0; i + 7 < length; i += 8) {					//loop unrolled to eight times
    sum1 += u[i] * v[i];						//sum the product of each item in
    sum2 += u[i+1] * v[i+1];						//the arrays
    sum3 += u[i+2] * v[i+2];						//sum eight products each iteration
    sum4 += u[i+3] * v[i+3];						//of the loop
    sum5 += u[i+4] * v[i+4];
    sum6 += u[i+5] * v[i+5];
    sum7 += u[i+6] * v[i+6];
    sum8 += u[i+7] * v[i+7];
    
  }
  for(; i < length; i++){						//finish any odd remainder
  sum1 += u[i] * v[i];							//at most 7 iterations
  }
  *dest = sum1 + sum2 + sum3 + sum4 + sum5 + sum6 + sum7 + sum8;	//store answer at dest
}

float *createArray(int length) {					//allocate memory for an array
  float *a = (float *)malloc(length * sizeof(float));			//the size of (length) floats
  for (int i = 0; i < length; ++i) {					//ex: 100,000 floats
    a[i] = rand()/(float)RAND_MAX;					//if length == 100,000
  }
  return a;
}


int main(){
	//inner1----------------------------------------------

	float *array1 = createArray(100000);				//create two arrays
	float *array2 = createArray(100000);				//size of 100,000
	float destination = 1.0;
	float *ptr = &destination;					//float ptr to result location
	int calls = 10000;						//times we call the function; 10,000
	clock_t start = clock();					//start timer
	for (int i = 1; i <= calls; i++){				//call function call times
	inner(array1, array2, 100000, ptr);
	}
	clock_t end = clock();						//end timer

	double totalTime = ((double) (end - start)) / CLOCKS_PER_SEC;	//print time
	printf("%f\n", totalTime);

	//inner1-----------------------------------------------
	
	//inner2-----------------------------------------------
	
	float destination2 = 1.0;					
	float *ptr2 = &destination2;					//float ptr to result location
	calls = 10000;							//times we call function; 10,000
	start = clock();						//start timer
	for (int i = 1; i <= calls; i++){				//call function call times
	inner2(array1, array2, 100000, ptr2);
	}
	end = clock();							//end timer

	totalTime = ((double) (end - start)) / CLOCKS_PER_SEC;		//print time
	printf("%f\n", totalTime);
	
	//inner2-----------------------------------------------
	
	//inner3-----------------------------------------------
	
	float destination3 = 1.0;
	float *ptr3 = &destination3;					//float ptr to result location
	calls = 10000;							//times we call function; 10,000
	start = clock();						//start timer
	for (int i = 1; i <= calls; i++){				//call function call times
	inner3(array1, array2, 100000, ptr3);		
	}
	end = clock();							//end timer

	totalTime = ((double) (end - start)) / CLOCKS_PER_SEC;		//print time
	printf("%f\n", totalTime);
	
	//inner3-----------------------------------------------
	
	free (array1);							//free array1 from memory
	free (array2);							//free array2 from memory
	
	//Answer:
	//inner1 average: 1.0334219
	//inner2 average: .5558678
	//inner3 average: .5141248
	//Obviously, the most efficient one was inner3, the eight times loop unrolling
	//however, occasionally, I would get a slower time with inner3 than inner2.
	//I believe this is becuase we ran out of registers a few times and had to access
	//memory. With this, and the fact that the time decrease is not that much,
	//I would probably just use loop unrolling 4.
	
	
	
	
	return 0;
}







