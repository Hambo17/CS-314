#include <stdio.h>
#include <stdlib.h>


unsigned int mask(int n){
	//Create a starting mask of all 1's.
	unsigned int main_mask = 0xFFFFFFFF;
	//Shift mask left by n to create a mask with the insignificant bits being 0's.
	unsigned int mask2 = main_mask << (n);
	//Invert that mask, to create a result with only the insignificant bits being 1's.
	unsigned int result = ~(mask2);
	//return answer.
	return result;
}

int main(int argc, char *argv[]) {
  if (argc == 2) {
    int n = strtol(argv[1], NULL, 10);
    printf("mask(%d): %X\n", n, mask(n));
  } else {
    // TODO - add any hardcoded test cases you'd like here!
        printf("mask(%d): %X\n", 1, mask(1));
        printf("mask(%d): %X\n", 2, mask(2));
        printf("mask(%d): %X\n", 3, mask(3));
        printf("mask(%d): %X\n", 5, mask(5));
        printf("mask(%d): %X\n", 8, mask(8));
        printf("mask(%d): %X\n", 16, mask(16));
        printf("mask(%d): %X\n", 31, mask(31));
  }
  return 0;
}
