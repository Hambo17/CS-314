#include <stdio.h>
#include <stdlib.h>

unsigned int extract (unsigned int x, int i){
	//Create a mask at the byte specified.
	unsigned int mask = 0xff << (i << 3);
	//remove the unwanted bytes form x and place whats left at the least significant byte.
	unsigned int result = (x & mask) >> (i << 3);
	//place the result in a signed int, and shift it left to byte 3 and back again, to perform
	//an arithmetic shift to preserve the signed character.
	int temp = (0xff & result) << (24);
	int temp2 = (temp >> 24);
	return temp2;
}

int main(int argc, char *argv[]) {
  if (argc == 3) {
    unsigned int x = strtoul(argv[1], NULL, 16);
    int i = strtol(argv[2], NULL, 10);
    printf("extract(%X, %d): 0x%08X\n", x, i, extract(x, i));
  } else {
    printf("extract(0x%X, %d): 0x%08X\n", 0x12345678, 0, extract(0x12345678, 0));
    printf("extract(0x%X, %d): 0x%08X\n", 0xF2345678, 0, extract(0xF2345678, 0));
    printf("extract(0x%X, %d): 0x%08X\n", 0xABCDEF00, 2, extract(0xABCDEF00, 2));
    printf("extract(0x0%X, %d): 0x%08X\n", 0x0BCDEF00, 2, extract(0x0BCDEF00, 2));
  }
  return 0;
}
